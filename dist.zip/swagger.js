"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.specs = void 0;
const swagger_jsdoc_1 = __importDefault(require("swagger-jsdoc"));
const eventDocs_1 = __importDefault(require("./swagger/eventDocs"));
const bookingDocs_1 = __importDefault(require("./swagger/bookingDocs"));
const options = {
    definition: {
        openapi: "3.0.0",
        info: {
            title: "Wine Events API",
            version: "1.0.0",
            description: "API documentation for Wine Events application",
        },
        servers: [
            {
                url: "http://localhost:3000",
                description: "Development server",
            },
        ],
        paths: {
            "/api/getEventById/{eventId}": eventDocs_1.default.getEventById,
            "/api/createEvent": eventDocs_1.default.createEvent,
            "/api/editEvent/{eventId}": eventDocs_1.default.editEvent,
            "/api/deleteEvent/{eventId}": eventDocs_1.default.deleteEvent,
            "/api/createUserAndBooking": bookingDocs_1.default.createUserAndBooking,
            "/api/getBookings": bookingDocs_1.default.getBookings,
            "/api/getBookingByUser/{useremail}": bookingDocs_1.default.getBookingByUser,
            "/api/editBooking/{bookingId}": bookingDocs_1.default.editBookingByBookingId,
        },
    },
    apis: [], // We're not using JSDoc comments anymore
};
exports.specs = (0, swagger_jsdoc_1.default)(options);
