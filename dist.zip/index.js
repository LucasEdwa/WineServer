"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.app = void 0;
const express_1 = __importDefault(require("express"));
const createTables_1 = __importDefault(require("./createTables"));
const connection_1 = __importDefault(require("./connection"));
const router_1 = __importDefault(require("./routes/router"));
const db_1 = require("./db");
const cors_1 = __importDefault(require("cors"));
exports.app = (0, express_1.default)();
// Middleware
exports.app.use((0, cors_1.default)({
    origin: ['http://localhost:5173', 'http://localhost:8888'],
    methods: ['GET', 'POST', 'PUT', 'DELETE'],
    allowedHeaders: ['Content-Type', 'Authorization'],
    credentials: true
}));
exports.app.use(express_1.default.json());
exports.app.use('/api', router_1.default);
// Initialize database
connection_1.default.getConnection()
    .then(connection => {
    console.log('Connected to the MySQL server.');
    connection.release();
    (0, createTables_1.default)().then(() => {
        (0, db_1.insertEvents)(); // Ensure this is called after tables are created
    });
})
    .catch(err => {
    console.error('Error connecting to the MySQL server:', err);
});
// Remove the express.listen since we're using Lambda
// const port = process.env.PORT || 3000;
// app.listen(port, () => console.log(`Server is running on port ${port}!`));
