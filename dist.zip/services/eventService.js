"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEvent = createEvent;
exports.editEvent = editEvent;
exports.deleteEvent = deleteEvent;
const path_1 = __importDefault(require("path"));
const connection_1 = __importDefault(require("../connection"));
async function createEvent(image, eventData) {
    const connection = await connection_1.default.getConnection();
    try {
        await connection.beginTransaction();
        // Save image
        const uploadPath = path_1.default.join(__dirname, '../../images/', image.name);
        const imageUrl = `/images/${image.name}`;
        await image.mv(uploadPath);
        // Insert event
        const [result] = await connection.query(`INSERT INTO events (
                title, description, imageUrl, date, 
                startTime, endTime, location, capacity, 
                price, currentAttendees, wineSelection, 
                activities, isPrivate
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`, [
            eventData.title,
            eventData.description,
            imageUrl,
            eventData.date,
            eventData.startTime,
            eventData.endTime,
            eventData.location,
            Number(eventData.capacity),
            Number(eventData.price),
            0,
            JSON.stringify([]),
            JSON.stringify([]),
            Boolean(eventData.isPrivate)
        ]);
        await connection.commit();
        return result.insertId;
    }
    catch (error) {
        await connection.rollback();
        throw error;
    }
    finally {
        connection.release();
    }
}
async function editEvent(eventId, eventData) {
    const connection = await connection_1.default.getConnection();
    try {
        await connection.beginTransaction();
        // Handle image update if provided
        let imageUrl = eventData.currentImageUrl;
        if (eventData.image) {
            const image = eventData.image;
            // Use the same path pattern as createEvent
            const uploadPath = path_1.default.join(__dirname, '../../images/', image.name);
            await image.mv(uploadPath);
            imageUrl = `/images/${image.name}`;
            console.log('Image uploaded to:', uploadPath);
        }
        // Update event
        await connection.query(`UPDATE events SET 
                title = ?, description = ?, imageUrl = ?,
                date = ?, startTime = ?, endTime = ?, 
                location = ?, capacity = ?, price = ?, 
                isPrivate = ? 
                WHERE id = ?`, [
            eventData.title,
            eventData.description,
            imageUrl,
            eventData.date,
            eventData.startTime,
            eventData.endTime,
            eventData.location,
            Number(eventData.capacity),
            Number(eventData.price),
            Boolean(eventData.isPrivate),
            eventId
        ]);
        await connection.commit();
        return eventId;
    }
    catch (error) {
        await connection.rollback();
        console.error('Error in editEvent:', error);
        throw error;
    }
    finally {
        connection.release();
    }
}
async function deleteEvent(eventId) {
    const connection = await connection_1.default.getConnection();
    try {
        await connection.query('DELETE FROM events WHERE id = ?', [eventId]);
    }
    finally {
        connection.release();
    }
}
